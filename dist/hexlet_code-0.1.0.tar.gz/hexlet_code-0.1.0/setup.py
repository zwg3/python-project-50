# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['Gendiff', 'Gendiff.scripts']

package_data = \
{'': ['*']}

install_requires = \
['flake8>=6.0.0,<7.0.0', 'pyyaml>=6.0,<7.0']

entry_points = \
{'console_scripts': ['gendiff = Gendiff.scripts.gendiff:main']}

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '0.1.0',
    'description': 'Difference generator',
    'long_description': '### Hexlet tests and linter status:\n![https://github.com/zwg3/python-project-50/actions/workflows/Project-50-ci.yml/badge.svg](https://github.com/zwg3/python-project-50/actions/workflows/Project-50-ci.yml/badge.svg)\n[![Actions Status](https://github.com/zwg3/python-project-50/workflows/hexlet-check/badge.svg)](https://github.com/zwg3/python-project-50/actions)\n<a href="https://codeclimate.com/github/zwg3/python-project-50/maintainability"><img src="https://api.codeclimate.com/v1/badges/ee26a262e35fc35b327f/maintainability" /></a>\n<a href="https://codeclimate.com/github/zwg3/python-project-50/test_coverage"><img src="https://api.codeclimate.com/v1/badges/ee26a262e35fc35b327f/test_coverage" /></a>\n\n### Requirements\n- python 3.10\n- pyyaml = 6.0\n\n### Installation:\nIn terminal type the following commands from the package directory:\n- make install\n- make build\n- make package-install\n\n### Usage:\nThe program is used to find differences between two files (.json or .yml format).\nAfter the installation use the following commands:\n- gendiff -f stylish <filepath1> <filepath2> (gets you a default difference)\n- gendiff -f json <filepath1> <filepath2> (gets you a json-formated difference)\n- gendiff -f plain <filepath1> <filepath2> (gets you a plain difference)  \nNote: if you do not specify the format (via -f), stylish format will be used as a default one.\n\n### Basic info\n[![asciicast](https://asciinema.org/a/i8tdenKgicgJUf5qPmWQwfmaX.svg)](https://asciinema.org/a/i8tdenKgicgJUf5qPmWQwfmaX)\n\n### Stylish format output\n[![asciicast](https://asciinema.org/a/8BUWuHAapNOQmhMYoMUzGB9iv.svg)](https://asciinema.org/a/8BUWuHAapNOQmhMYoMUzGB9iv)\n\n### Plain format output\n[![asciicast](https://asciinema.org/a/bPSPEtGk3AIwzNONDrzPPfuNa.svg)](https://asciinema.org/a/bPSPEtGk3AIwzNONDrzPPfuNa)\n\n### Json format output\n[![asciicast](https://asciinema.org/a/oufXaWoxmjtVl4chZg91Ec0zL.svg)](https://asciinema.org/a/oufXaWoxmjtVl4chZg91Ec0zL)\n\n',
    'author': 'zwg',
    'author_email': 'zwg.work.mail@gmail.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
