import Gendiff.scripts.stylish_format as stylish_format


def json_(dict_data):
    return stylish_format.stylish(dict_data)
