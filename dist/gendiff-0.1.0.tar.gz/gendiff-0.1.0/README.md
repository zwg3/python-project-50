### Hexlet tests and linter status:
![https://github.com/zwg3/python-project-50/actions/workflows/Project-50-ci.yml/badge.svg](https://github.com/zwg3/python-project-50/actions/workflows/Project-50-ci.yml/badge.svg)
[![Actions Status](https://github.com/zwg3/python-project-50/workflows/hexlet-check/badge.svg)](https://github.com/zwg3/python-project-50/actions)
<a href="https://codeclimate.com/github/zwg3/python-project-50/maintainability"><img src="https://api.codeclimate.com/v1/badges/ee26a262e35fc35b327f/maintainability" /></a>
<a href="https://codeclimate.com/github/zwg3/python-project-50/test_coverage"><img src="https://api.codeclimate.com/v1/badges/ee26a262e35fc35b327f/test_coverage" /></a>
