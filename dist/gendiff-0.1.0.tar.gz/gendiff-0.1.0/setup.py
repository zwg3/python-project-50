# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['gendiff', 'gendiff.scripts']

package_data = \
{'': ['*']}

install_requires = \
['flake8>=6.0.0,<7.0.0', 'pytest-cov>=4.0.0,<5.0.0']

entry_points = \
{'console_scripts': ['gendiff = gendiff.scripts.gendiff:main']}

setup_kwargs = {
    'name': 'gendiff',
    'version': '0.1.0',
    'description': 'Difference generator',
    'long_description': '### Hexlet tests and linter status:\n![https://github.com/zwg3/python-project-50/actions/workflows/Project-50-ci.yml/badge.svg](https://github.com/zwg3/python-project-50/actions/workflows/Project-50-ci.yml/badge.svg)\n[![Actions Status](https://github.com/zwg3/python-project-50/workflows/hexlet-check/badge.svg)](https://github.com/zwg3/python-project-50/actions)\n<a href="https://codeclimate.com/github/zwg3/python-project-50/maintainability"><img src="https://api.codeclimate.com/v1/badges/ee26a262e35fc35b327f/maintainability" /></a>\n<a href="https://codeclimate.com/github/zwg3/python-project-50/test_coverage"><img src="https://api.codeclimate.com/v1/badges/ee26a262e35fc35b327f/test_coverage" /></a>\n',
    'author': 'zwg',
    'author_email': 'zwg.work.mail@gmail.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
